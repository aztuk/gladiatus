/**
 * Composant HUD — Affiche les derniers messages système (logs).
 * Version autonome avec signal local temporaire.
 */

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hud-log',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hud-log.component.html',
  styleUrls: ['./hud-log.component.scss'],
})
export class HudLogComponent {
  /**
   * Signal local simulant des logs système.
   * Peut être remplacé ensuite par un inject DebugService.
   */
  private _logs = signal<string[]>([
    'Cycle 1 démarré',
    '+10 or reçus du combat',
    'Réputation avec l’Armée : +2',
  ]);

  logs = this._logs;

  /**
   * Méthode publique à connecter plus tard à un vrai service.
   */
  addLog(entry: string) {
    const current = this._logs();
    this._logs.set([...current.slice(-4), entry]);
  }
}
