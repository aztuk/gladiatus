import { Injectable, signal } from '@angular/core';
import { GameContextState, GladiatorState } from './game-context.model';
import { ReputationService } from './services/reputation.service';
import { GameClockService } from '../clock/game-clock.service';
import { FactionId } from '../models/reputation.model';

/**
 * Service principal du contexte de jeu.
 * Gère les états globaux (ressources, réputation, cycle...) et expose l’état consolidé.
 */
@Injectable({ providedIn: 'root' })
export class GameContextService {
  // === GLOBAL ===
  private gold = signal(1000);
  private prestige = signal(0);
  private materials = signal<Record<string, number>>({});

  // === PAR GLADIATEUR ===
  private fameMap = new Map<string, number>();
  private fatigueMap = new Map<string, number>();
  private moralMap = new Map<string, number>();
  private xpMap = new Map<string, Record<string, number>>();
  private virtusRevealed = new Set<string>();

  constructor(
    private readonly reputation: ReputationService,
  ) {}

  // === GOLD ===
  incrementGold(amount: number): void {
    this.gold.update(g => g + amount);
  }

  spendGold(amount: number): void {
    this.gold.update(g => Math.max(0, g - amount));
  }

  getGold(): number {
    return this.gold();
  }

  // === PRESTIGE ===
  addPrestige(amount: number): void {
    this.prestige.update(p => p + amount);
  }

  getPrestige(): number {
    return this.prestige();
  }

  // === MATERIALS ===
  addMaterial(materialId: string, amount: number): void {
    const current = { ...this.materials() };
    current[materialId] = (current[materialId] ?? 0) + amount;
    this.materials.set(current);
  }

  spendMaterial(materialId: string, amount: number): void {
    const current = { ...this.materials() };
    current[materialId] = Math.max(0, (current[materialId] ?? 0) - amount);
    this.materials.set(current);
  }

  getMaterials(): Record<string, number> {
    return this.materials();
  }

  // === CÉLÉBRITÉ / FAME ===
  modifyFame(gladId: string, amount: number): void {
    const current = this.fameMap.get(gladId) ?? 0;
    this.fameMap.set(gladId, current + amount);
  }

  getFame(gladId: string): number {
    return this.fameMap.get(gladId) ?? 0;
  }

  // === FATIGUE ===
  addFatigue(gladId: string, amount: number): void {
    const current = this.fatigueMap.get(gladId) ?? 0;
    this.fatigueMap.set(gladId, current + amount);
  }

  removeFatigue(gladId: string, amount: number): void {
    const current = this.fatigueMap.get(gladId) ?? 0;
    this.fatigueMap.set(gladId, Math.max(0, current - amount));
  }

  getFatigue(gladId: string): number {
    return this.fatigueMap.get(gladId) ?? 0;
  }

  // === MORAL ===
  modifyMoral(gladId: string, delta: number): void {
    const current = this.moralMap.get(gladId) ?? 10;
    const next = Math.max(0, current + delta);
    this.moralMap.set(gladId, next);
  }

  getMoral(gladId: string): number {
    return this.moralMap.get(gladId) ?? 10;
  }

  // === XP ===
  addXP(gladId: string, skill: string, xp: number): void {
    const current = this.xpMap.get(gladId) ?? {};
    current[skill] = (current[skill] ?? 0) + xp;
    this.xpMap.set(gladId, current);
  }

  getXP(gladId: string): Record<string, number> {
    return this.xpMap.get(gladId) ?? {};
  }

  // === VIRTUS ===
  revealVirtus(gladId: string): void {
    this.virtusRevealed.add(gladId);
  }

  hasRevealedVirtus(gladId: string): boolean {
    return this.virtusRevealed.has(gladId);
  }

  // === RÉPUTATION ===
  getReputation(faction: FactionId): number {
    return this.reputation.getReputation(faction);
  }

  modifyReputation(faction: FactionId, amount: number): void {
    this.reputation.modifyReputation(faction, amount);
  }

  // === EXPORT GLOBAL ===
  exportCurrentState(): GameContextState {
    const gladiators: Record<string, GladiatorState> = {};
    const ids = new Set<string>([
      ...this.fameMap.keys(),
      ...this.fatigueMap.keys(),
      ...this.moralMap.keys(),
      ...this.xpMap.keys(),
      ...this.virtusRevealed,
    ]);

    for (const id of ids) {
      gladiators[id] = {
        fame: this.getFame(id),
        fatigue: this.getFatigue(id),
        moral: this.getMoral(id),
        virtusRevealed: this.hasRevealedVirtus(id),
        xp: this.getXP(id),
        traits: [], // ⚠️ délégué à TraitEngineService
      };
    }

    return {
      gold: this.getGold(),
      prestige: this.getPrestige(),
      materials: this.getMaterials(),
      currentCycle: GameClockService.instance.getCurrentCycle(),
      reputation: this.reputation.exportState(),
      gladiators,
    };
  }
}

/**
 * Fournisseur Angular pour injection dans `app.config.ts`
 */
export function provideContext() {
  return {
    provide: GameContextService,
    useClass: GameContextService,
  };
}
